# yandexgptlite
YandexGPT Lite Python Connector
